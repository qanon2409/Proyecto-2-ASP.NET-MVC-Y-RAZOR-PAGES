﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using NewsServerAppP2.Models;
using NewsServerAppP2.Data;
using Microsoft.EntityFrameworkCore;

namespace NewsServerAppP2.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly PROYECTO2TIContext _context;


        public IndexModel(ILogger<IndexModel> logger, PROYECTO2TIContext context)
        {
            _logger = logger;
            _context = context;


        }
        public IEnumerable<Noticia> news { get; set; }

       



        //get the news 
        public void OnGet()
        {
            news = _context.Noticias.ToList();
                

        }
    }
}